package TestProject;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;
import utils.ConfigUtils;


import java.io.IOException;
import java.util.Properties;

public class main {



    @Test(description = "test automation", priority = 1)
    public static void main (String [] args) throws InterruptedException, IOException {

        System.setProperty("webdriver.chrome.driver", "E:\\breez\\chromedriver_win32 (1)\\chromedriver.exe");


        ChromeOptions options = new ChromeOptions();
        options.addArguments("start-maximized");
        WebDriver driver = new ChromeDriver(options);

        Properties prop = ConfigUtils.getProps( "data");

        driver.get(prop.getProperty("URL"));
        Thread.sleep(2000);

        LoginPage loginPg = new LoginPage();
        loginPg.login(driver);
        

        try {
            org.openqa.selenium.support.ui.WebDriverWait wait = new org.openqa.selenium.support.ui.WebDriverWait(driver, 1 /*timeout in seconds*/);
            if (wait.until(org.openqa.selenium.support.ui.ExpectedConditions.alertIsPresent()) == null) {
                System.out.println("alert was not present");
            } else {
                System.out.println("alert was present");
                //Handle Alert here
                driver.switchTo().alert().accept();
                //Or
                //driver.switchTo().alert().dismiss();
            }
        } catch (Exception e) {
            System.out.println("alert was not present");

        }

        Thread.sleep(3000);
// Assertion
        String text = driver.findElement(By.cssSelector("div.page_wrapper div.inventory_container div.inventory_list div.inventory_item:nth-child(1) div.inventory_item_description div.inventory_item_label a:nth-child(1) > div.inventory_item_name")).getText();
        if (text.contains("Sauce Labs Backpack"))
            System.out.println("Login Successfully");


        
        ProductPage Productpg = new ProductPage();
        Productpg.Add(driver);

        try {
            org.openqa.selenium.support.ui.WebDriverWait wait = new org.openqa.selenium.support.ui.WebDriverWait(driver, 1 /*timeout in seconds*/);
            if (wait.until(org.openqa.selenium.support.ui.ExpectedConditions.alertIsPresent()) == null) {
                System.out.println("alert was not present");
            } else {
                System.out.println("alert was present");
                //Handle Alert here
                driver.switchTo().alert().accept();
                //Or
                //driver.switchTo().alert().dismiss();
            }
        } catch (Exception e) {
            System.out.println("alert was not present");

        }

        Thread.sleep(3000);
// Assertion

            System.out.println("Product add successfully");
        
            Productpg.Remove(driver);
            Thread.sleep(5000);

            String url1 = driver.getCurrentUrl();
            System.out.println(url1);


            System.out.println("Product Remove Successfully");
            
            
            loginPg.logout(driver);
            Thread.sleep(5000);

            String url = driver.getCurrentUrl();
            System.out.println(url);


            System.out.println("Logout Successfully");
        driver.quit();

        }

   {






        }



    }



















