package TestProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ProductPage {

    // Page Class using POM
    public void Add (WebDriver driver) throws InterruptedException {

        driver.findElement(By.id("add-to-cart-sauce-labs-backpack")).click();
        driver.findElement(By.className("shopping_cart_link")).click();
        Thread.sleep(3000);

    }
    public void Remove (WebDriver driver) throws InterruptedException {

        driver.findElement(By.id("remove-sauce-labs-backpack")).click();
        Thread.sleep(3000);
        


    }


}
